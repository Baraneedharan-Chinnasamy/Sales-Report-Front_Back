import React from 'react';
import TabContainer from './components/TabContainer';

function App() {
  return (
    <div>
      <TabContainer />
    </div>
  );
}

export default App;
