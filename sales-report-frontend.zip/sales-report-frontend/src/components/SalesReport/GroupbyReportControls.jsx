import React, { useEffect, useMemo } from 'react';
import Select from 'react-select';
import {
  FunnelIcon,
  ArrowDownTrayIcon,
  MagnifyingGlassIcon,
  CalendarDaysIcon,
  BuildingOfficeIcon,
  TableCellsIcon,
  ChartBarIcon,
  XMarkIcon,
  EllipsisHorizontalIcon,
} from '@heroicons/react/24/outline';
import useColumnOptions from './hooks/useColumnOptions';
import useExportToSheet from './hooks/useExportToSheet';


const GroupbyReportControls = ({
  startDate = '',
  setStartDate = () => {},
  endDate = '',
  setEndDate = () => {},
  business = '',
  setBusiness = () => {},
  groupBy = [],
  setGroupBy = () => {},
  filterOpen = false,
  setFilterOpen = () => {},
  fetchData = () => {},
  exportMainDataToCSV = () => {},
  rowData = [],
  selectedColumns = [],
  setSelectedColumns = () => {},
  appliedFilters = {},
   loading = false 
}) => {
  const columnOptions = useColumnOptions(business);
  const filterCount = appliedFilters ? Object.keys(appliedFilters).length : 0;
  const { exportToGoogleSheet, loading: exporting } = useExportToSheet();
  useEffect(() => {
    if (typeof setGroupBy === 'function') {
      setGroupBy((prev = []) =>
        Array.isArray(prev)
          ? prev.filter((item) => selectedColumns.includes(item))
          : []
      );
    }
  }, [selectedColumns, setGroupBy]);

  const selectedColumnsOptions = useMemo(() => {
    return Array.isArray(selectedColumns)
      ? selectedColumns.map((col) => ({ value: col, label: col }))
      : [];
  }, [selectedColumns]);

  const selectedGroupByOptions = useMemo(() => {
    return Array.isArray(groupBy)
      ? groupBy.map((col) => ({ value: col, label: col }))
      : [];
  }, [groupBy]);

  // Custom MultiValue component that shows count with dropdown
  const CustomMultiValue = ({ data, removeProps, selectProps }) => {
    const isGroupBy = selectProps.isGroupBy;
    const allValues = selectProps.value || [];
    const currentIndex = allValues.findIndex(item => item.value === data.value);
    
    // Show only first item with count, others hidden
    if (currentIndex === 0 && allValues.length > 1) {
      return (
        <div style={isGroupBy ? styles.groupByMultiValue : styles.multiValue}>
          <span style={styles.multiValueText}>{data.label}</span>
          <span style={styles.countBadge}>+{allValues.length - 1}</span>
        </div>
      );
    } else if (currentIndex === 0) {
      return (
        <div style={isGroupBy ? styles.groupByMultiValue : styles.multiValue}>
          <span style={styles.multiValueText}>{data.label}</span>
          <button
            {...removeProps}
            style={styles.removeButton}
            onClick={(e) => {
              e.stopPropagation();
              removeProps.onClick(e);
            }}
          >
            <XMarkIcon style={styles.removeIcon} />
          </button>
        </div>
      );
    }
    
    return null; // Hide additional values
  };

  return (
    <div style={styles.container}>
      <div style={styles.formContainer}>
        {/* First Row - Main Controls */}
        <div style={styles.controlsRow}>
          <div style={styles.dateGroup}>
            <label style={styles.label}>Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              style={styles.dateInput}
            />
          </div>

          <div style={styles.dateGroup}>
            <label style={styles.label}>End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              style={styles.dateInput}
            />
          </div>

          <div style={styles.businessGroup}>
            <label style={styles.label}>Business ID</label>
            <input
              type="text"
              value={business}
              onChange={(e) => setBusiness(e.target.value)}
              style={styles.textInput}
            />
          </div>

          <div style={styles.selectGroup}>
            <div style={styles.labelWithBadge}>
              <label style={styles.labelselect}>Select Columns</label>
              {Array.isArray(selectedColumns) && selectedColumns.length > 0 && (
                <span style={styles.labelCount}>{selectedColumns.length}</span>
              )}
            </div>
            <Select
              isMulti
              options={columnOptions}
              value={selectedColumnsOptions}
              onChange={(selected) => {
                const values = Array.isArray(selected)
                  ? selected.map((opt) => opt.value)
                  : [];
                setSelectedColumns(values);
              }}
              styles={customSelectStyles}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
              placeholder="Choose columns..."
              components={{
                MultiValue: CustomMultiValue,
              }}
              menuPlacement="auto"
              menuPosition="fixed"
              isGroupBy={false}
            />
          </div>
          <div style={styles.selectGroup}>
            <div style={styles.labelWithBadge}>
              <label style={styles.labelselect}>Group By Fields</label>
              {Array.isArray(groupBy) && groupBy.length > 0 && (
                <span style={styles.groupByCount}>{groupBy.length}</span>
              )}
            </div>
            <Select
              isMulti
              options={selectedColumnsOptions}
              value={selectedGroupByOptions}
              onChange={(selected) => {
                const values = Array.isArray(selected)
                  ? selected.map((opt) => opt.value)
                  : [];
                setGroupBy(values);
              }}
              styles={{
                ...customSelectStyles,
                control: (base, state) => ({
                  ...customSelectStyles.control(base, state),
                  opacity: selectedColumns.length === 0 ? 0.6 : 1,
                }),
              }}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
              placeholder={
                selectedColumns.length === 0
                  ? 'Select columns first...'
                  : 'Choose grouping fields...'
              }
              isDisabled={selectedColumns.length === 0}
              components={{
                MultiValue: CustomMultiValue,
              }}
              menuPlacement="auto"
              menuPosition="fixed"
              isGroupBy={true}
            />
          </div>
        </div>

        {/* Second Row - Action Buttons */}
        <div style={styles.actionRow}>
          <button
            onClick={() => setFilterOpen(!filterOpen)}
            style={{
              ...styles.filterButton,
              ...(filterOpen ? styles.filterButtonActive : {}),
            }}
          >
            <FunnelIcon style={styles.buttonIcon} />
            Advanced Filters
            {filterCount > 0 && <span style={styles.badge}>{filterCount}</span>}
          </button>

          <div style={styles.rightActions}>
          <button
            onClick={fetchData}
            style={styles.fetchButton}
            disabled={loading}
          >
            {loading ? 'Loading...' : (
              <>
                <MagnifyingGlassIcon style={styles.buttonIcon} />
                Fetch
              </>
            )}
          </button>

            <button
              onClick={() => exportMainDataToCSV(selectedColumns)}
              disabled={!Array.isArray(rowData) || rowData.length === 0}
              style={{
                ...styles.exportButton,
                ...((!Array.isArray(rowData) || rowData.length === 0) ? styles.exportButtonDisabled : {}),
              }}
            >
              <ArrowDownTrayIcon style={styles.buttonIcon} />
              Export CSV
            </button>
            <button
            onClick={() => exportToGoogleSheet(business, rowData)}
            disabled={!Array.isArray(rowData) || rowData.length === 0 || !business}
            style={{
              ...styles.exportButton,
              backgroundColor: '#ffffff', 
              opacity: (!rowData || rowData.length === 0 || !business) ? 0.5 : 1,
            }}
          >
            📤 Export to Google Sheet
          </button>

          </div>
        </div>
      </div>
    </div>
  );
};

const customSelectStyles = {
  control: (base, state) => ({
  ...base,
  height: '29px',
  minHeight: '29px',
  padding: '0', // Remove padding from control
  fontSize: '12px', // Consistent font size
  borderRadius: '6px',
  borderColor: state.isFocused ? '#3b82f6' : '#d1d5db',
  borderWidth: '1px',
  boxShadow: state.isFocused ? '0 0 0 3px rgba(59, 130, 246, 0.1)' : 'none',
  backgroundColor: '#ffffff', // Changed from #f8fafc to match inputs
  transition: 'all 0.15s ease',
  boxSizing: 'border-box',
}),
indicatorSeparator: () => ({
  display: 'none',
}),
dropdownIndicator: (base, state) => ({
  ...base,
  padding: '4px 2px 7px 2px', // reduce or increase as needed
  color: state.isFocused ? '#3b82f6' : '#9ca3af', // blue when focused, gray otherwise
  transition: 'color 0.2s ease',
  svg: {
    width: '16px',  
    height: '16px',
  },
  '&:hover': {
    color: '#3b82f6', // optional: hover color
  },
}),
clearIndicator: (base, state) => ({
  ...base,
  padding: '4px 2px 7px 2px',
  color: state.isFocused ? '#3b82f6' : '#9ca3af',
  cursor: 'pointer',
  '& svg': {
    width: '14px',
    height: '14px',
  },
  '&:hover': {
    color: '#3b82f6', // Hover color for the X
  },
}),

  valueContainer: (base) => ({
  ...base,
  padding: '2px 8px 9.5px 5px', // Reduced padding
  flexWrap: 'wrap',
  overflow: 'hidden',
}),
  placeholder: (base) => ({
    ...base,
    color: '#9ca3af',
    fontSize: '13px',
  }),
  menu: (base) => ({
    ...base,
    zIndex: 9999,
    borderRadius: '8px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    border: '1px solid #e5e7eb',
  }),
  option: (base, state) => ({
    ...base,
    backgroundColor: state.isSelected
      ? '#3b82f6'
      : state.isFocused
      ? '#f8fafc'
      : 'white',
    color: state.isSelected ? 'white' : '#374151',
    padding: '8px 12px',
    fontSize: '13px',
    cursor: 'pointer',
    '&:hover': {
      backgroundColor: state.isSelected ? '#3b82f6' : 'rgb(220, 231, 243)',
    },
  }),
  menuPortal: base => ({ ...base, zIndex: 9999 }),
};

const styles = {
  container: {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    border: '1px solid #e5e7eb',
    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
  },
  formContainer: {
  padding: '16px 20px', // Reduced top/bottom padding from 20px to 16px
},
  controlsRow: {
  display: 'grid',
  gridTemplateColumns: 'auto auto 1fr 2fr 2fr',
  gap: '12px', // Reduced from 16px
  alignItems: 'end',
  marginBottom: '12px', // Reduced from 16px
},
  dateGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '140px',
  },
  businessGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '160px',
  },
  selectGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '200px',
  },
  actionRow: {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingTop: '5px', // Reduced from 16px
  marginTop: '4px', // Add small margin
},
  rightActions: {
    display: 'flex',
    gap: '8px',
  },
  filterButton: {
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  padding: '6px 12px', // Consistent with other buttons
  fontSize: '13px', // Match other text
  fontWeight: '500',
  borderRadius: '6px',
  border: '1px solid #d1d5db',
  backgroundColor: '#ffffff',
  color: '#374151',
  cursor: 'pointer',
  transition: 'all 0.15s ease',
  whiteSpace: 'nowrap',
  height: '29px', // Match input height
  boxSizing: 'border-box',
},
  label: {
  fontSize: '12px',
  fontWeight: '600',
  color: '#374151',
  marginBottom: '4px', // Add consistent bottom margin
  display: 'block',
},
labelselect: {
  fontSize: '12px',
  fontWeight: '600',
  color: '#374151',
  marginBottom: '0px', // Add consistent bottom margin
  display: 'block',
},
  labelCount: {
  fontSize: '10px',
  color: '#3b82f6',
  backgroundColor: '#eff6ff',
  padding: '2px 6px',
  borderRadius: '10px',
  fontWeight: '500',
  flexShrink: 0, // Prevent shrinking
  minWidth: 'fit-content',
},
  groupByCount: {
  fontSize: '10px',
  color: '#3b82f6', // Changed to match labelCount color
  backgroundColor: '#eff6ff', // Changed to match labelCount background
  padding: '2px 6px',
  borderRadius: '10px',
  fontWeight: '500',
  flexShrink: 0, // Prevent shrinking
  minWidth: 'fit-content',
},
  dateInput: {
  padding: '4px 8px', // Reduced vertical padding
  height: '29px', // Match select height exactly
  borderRadius: '6px',
  border: '1px solid #d1d5db',
  fontSize: '13px',
  backgroundColor: '#ffffff',
  transition: 'all 0.15s ease',
  minWidth: '130px',
  boxSizing: 'border-box', // Important for consistent sizing
},
  textInput: {
  padding: '4px 8px', // Reduced vertical padding
  height: '29px', // Match select height exactly
  borderRadius: '6px',
  border: '1px solid #d1d5db',
  fontSize: '13px',
  backgroundColor: '#ffffff',
  transition: 'all 0.15s ease',
  boxSizing: 'border-box', // Important for consistent sizing
},
  multiValue: {
  display: 'flex',
  alignItems: 'center',
  backgroundColor: '#eff6ff',
  color: '#1e40af',
  padding: '3px 6px', // Slightly increased padding for better alignment
  borderRadius: '4px',
  fontSize: '12px',
  fontWeight: '500',
  gap: '3px', // Reduced gap for tighter alignment
  border: '1px solid #dbeafe',
  maxWidth: '100%',
  overflow: 'hidden',
  height: '20px', // Fixed height for consistency
  boxSizing: 'border-box',
  lineHeight: '1', // Force consistent line height
},

  groupByMultiValue: {
  display: 'flex',
  alignItems: 'center',
  backgroundColor: '#eff6ff', // Changed to match multiValue
  color: '#1e40af', // Changed to match multiValue
  padding: '3px 6px', // Slightly increased padding for better alignment
  borderRadius: '4px',
  fontSize: '12px',
  fontWeight: '500',
  gap: '3px', // Reduced gap for tighter alignment
  border: '1px solid #dbeafe', // Changed to match multiValue
  maxWidth: '100%',
  overflow: 'hidden',
  height: '20px', // Fixed height for consistency
  boxSizing: 'border-box',
  lineHeight: '1', // Force consistent line height
},
  multiValueText: {
    flex: 1,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    lineHeight: '14px', // Match the container height for perfect alignment
    display: 'flex',
    alignItems: 'center', // Center the text vertically
    height: '14px', // Match the available height within padding
  },
  countBadge: {
  backgroundColor: 'rgba(30, 64, 175, 0.2)', // Consistent with multiValue color scheme
  color: '#1e40af',
  borderRadius: '6px', // Slightly smaller radius
  padding: '0px 4px', // Tighter padding
  fontSize: '10px',
  fontWeight: '600',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  minWidth: '14px',
  height: '12px', // Reduced height for better proportion
  lineHeight: '12px', // Match height
  flexShrink: 0, // Prevent shrinking
},
  removeButton: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '0px', // Remove padding
    borderRadius: '2px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0, // Prevent shrinking
    width: '14px', // Fixed width
    height: '14px', // Fixed height to match text height
    ':hover': {
      backgroundColor: 'rgba(30, 64, 175, 0.1)',
    },
  },
  removeIcon: {
    width: '10px',
    height: '10px',
  },
  filterButtonActive: {
    backgroundColor: '#1f2937',
    color: '#ffffff',
    borderColor: '#1f2937',
  },
  fetchButton: {
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  padding: '6px 16px', // Reduced vertical padding
  fontSize: '13px', // Consistent with other elements
  fontWeight: '500',
  borderRadius: '6px',
  border: 'none',
  backgroundColor: '#3b82f6',
  color: '#ffffff',
  cursor: 'pointer',
  transition: 'all 0.15s ease',
  height: '29px', // Match input height
  boxSizing: 'border-box',
},
  exportButton: {
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  padding: '6px 16px', // Reduced vertical padding
  fontSize: '13px', // Consistent with other elements
  fontWeight: '500',
  borderRadius: '6px',
  border: '1px solid #d1d5db',
  backgroundColor: '#ffffff',
  color: '#374151',
  cursor: 'pointer',
  transition: 'all 0.15s ease',
  height: '29px', // Match input height
  boxSizing: 'border-box',
},
  exportButtonDisabled: {
    opacity: 0.5,
    cursor: 'not-allowed',
    ':hover': {
      backgroundColor: '#ffffff',
      borderColor: '#d1d5db',
    },
  },
  buttonIcon: {
    width: '16px',
    height: '16px',
  },
  labelWithBadge: {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: '4px',
  width: '100%',
},
  badge: {
    backgroundColor: '#ef4444',
    color: '#ffffff',
    fontSize: '11px',
    fontWeight: '600',
    borderRadius: '10px',
    padding: '2px 6px',
    marginLeft: '4px',
  },
};

export default GroupbyReportControls;