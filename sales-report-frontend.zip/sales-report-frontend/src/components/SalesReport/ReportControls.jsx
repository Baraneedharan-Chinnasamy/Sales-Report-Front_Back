import React, { useState, useEffect } from 'react';
import {
  XMarkIcon,
  ArrowDownTrayIcon,
  FunnelIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/solid';
import useExportToSheet from './hooks/useExportToSheet';


const ReportControls = ({
  aggregation,
  setAggregation,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  compareStartDate,
  setCompareStartDate,
  compareEndDate,
  setCompareEndDate,
  business,
  setBusiness,
  fetchData,
  exportMainDataToCSV,
  rowData,
  filterOpen,
  setFilterOpen,
  appliedFilters,
  setTargetModalOpen,
  loading
}) => {
  const [startWeekYear, setStartWeekYear] = useState(new Date().getFullYear());
  const [endWeekYear, setEndWeekYear] = useState(new Date().getFullYear());
  const [startMonth, setStartMonth] = useState(new Date().getMonth());
  const [endMonth, setEndMonth] = useState(new Date().getMonth());
  const { exportToGoogleSheet, load, successMessage, error } = useExportToSheet();

  // Local date formatting to avoid timezone issues
  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, '0');
    const day = `${date.getDate()}`.padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const getWeekNumber = (date) => {
    const tempDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    tempDate.setHours(0, 0, 0, 0);
    tempDate.setDate(tempDate.getDate() + 4 - (tempDate.getDay() || 7));
    const yearStart = new Date(tempDate.getFullYear(), 0, 1);
    return Math.ceil((((tempDate - yearStart) / 86400000) + 1) / 7);
  };

  const getISOWeekStartDate = (year, week) => {
    const jan4 = new Date(year, 0, 4);
    const jan4Day = jan4.getDay() || 7;
    const week1Start = new Date(jan4);
    week1Start.setDate(jan4.getDate() - jan4Day + 1);

    const targetDate = new Date(week1Start);
    targetDate.setDate(week1Start.getDate() + (week - 1) * 7);
    return targetDate;
  };

  const updateDateByWeek = (week, year, dateType, setDate) => {
    const weekStart = getISOWeekStartDate(year, week);
    if (dateType === 'start') {
      setDate(formatDate(weekStart));
    } else {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      setDate(formatDate(weekEnd));
    }
  };

  const updateMonth = (month, dateType, setDate) => {
    const monthIndex = parseInt(month);

    if (dateType === 'start') {
      setStartMonth(monthIndex);
      // Use monthIndex and startWeekYear directly, not state variables
      const date = new Date(startWeekYear, monthIndex, 1);
      setDate(formatDate(date));
    } else {
      setEndMonth(monthIndex);
      // Use monthIndex and endWeekYear directly here to avoid stale state
      const date = new Date(endWeekYear, monthIndex + 1, 0); // last day of the month
      setDate(formatDate(date));
    }
  };

  const updateYear = (year, dateType, setDate) => {
    const y = parseInt(year);
    if (isNaN(y)) return;

    if (dateType === 'start') {
      setStartWeekYear(y);
      // Use y and startMonth directly
      const date = new Date(y, startMonth, 1);
      setDate(formatDate(date));
    } else {
      setEndWeekYear(y);
      // Use y and endMonth directly
      const date = new Date(y, endMonth + 1, 0);
      setDate(formatDate(date));
    }
  };

  useEffect(() => {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const week = getWeekNumber(now);

  if (aggregation === 'weekly') {
    const start = getISOWeekStartDate(currentYear, week);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    setStartDate(formatDate(start));
    setEndDate(formatDate(end));
  } else if (aggregation === 'monthly') {
    const start = new Date(currentYear, currentMonth, 1);
    const end = new Date(currentYear, currentMonth + 1, 0);
    setStartDate(formatDate(start));
    setEndDate(formatDate(end));
  } else if (aggregation === 'daily') {
    const today = formatDate(now);
    setStartDate(today);
    setEndDate(today);
  } else if (aggregation === 'custom' || aggregation === 'compare') {
    // Do not auto-change in custom or compare
    // Maybe keep or clear depending on your preference
  }
}, [aggregation]);


  const renderDateInput = (dateType, value, setter) => {
    const currentWeek = getWeekNumber(new Date(value));
    const selectedYear = dateType === 'start' ? startWeekYear : endWeekYear;
    const setYear = dateType === 'start' ? setStartWeekYear : setEndWeekYear;

    switch (aggregation) {
      case 'weekly':
        return (
          <div style={styles.weekSelector}>
            <select
              value={currentWeek}
              onChange={(e) => updateDateByWeek(parseInt(e.target.value), selectedYear, dateType, setter)}
              style={styles.weekInput}
            >
              {Array.from({ length: 53 }, (_, i) => i + 1).map((week) => {
                const weekStartDate = getISOWeekStartDate(selectedYear, week);
                const formattedDate = weekStartDate.toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: 'short',
                });
                return (
                  <option key={week} value={week}>
                    {`Week ${week} (${formattedDate})`}
                  </option>
                );
              })}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => {
                const year = parseInt(e.target.value);
                setYear(year);
                updateDateByWeek(currentWeek, year, dateType, setter);
              }}
              style={styles.yearInput}
            >
              {[2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030].map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        );
      case 'monthly':
        const selectedMonth = dateType === 'start' ? startMonth : endMonth;
        return (
          <div style={styles.monthSelector}>
            <select
              value={selectedMonth}
              onChange={(e) => updateMonth(e.target.value, dateType, setter)}
              style={styles.monthInput}
            >
              {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, index) => (
                <option key={month} value={index}>{month}</option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => updateYear(e.target.value, dateType, setter)}
              style={styles.yearInput}
            >
              {[2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030].map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        );
      default:
        return (
          <input
            type="date"
            value={value}
            onChange={(e) => setter(e.target.value)}
            style={styles.input}
          />
        );
    }
  };

  const filterCount = Object.keys(appliedFilters || {}).length;

  return (
    <div style={styles.container}>
      <div style={styles.inputRow}>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Aggregation</label>
          <select
            value={aggregation}
            onChange={(e) => setAggregation(e.target.value)}
            style={styles.selectInput}
          >
            <option value="">Select Aggregation</option>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="custom">Custom</option>
            <option value="compare">Compare</option>
          </select>
        </div>

        <div style={styles.inputGroup}>
          <label style={styles.label}>Start Date</label>
          {renderDateInput('start', startDate, setStartDate)}
        </div>

        <div style={styles.inputGroup}>
          <label style={styles.label}>End Date</label>
          {renderDateInput('end', endDate, setEndDate)}
        </div>

        {aggregation === 'compare' && (
          <>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Compare Start</label>
              <input
                type="date"
                value={compareStartDate}
                onChange={(e) => setCompareStartDate(e.target.value)}
                style={styles.input}
              />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Compare End</label>
              <input
                type="date"
                value={compareEndDate}
                onChange={(e) => setCompareEndDate(e.target.value)}
                style={styles.input}
              />
            </div>
          </>
        )}

        <div style={styles.inputGroup}>
          <label style={styles.label}>Business ID</label>
          <input
            type="text"
            value={business}
            onChange={(e) => setBusiness(e.target.value)}
            style={styles.input}
          />
        </div>
      </div>

      <div style={styles.buttonRow}>
  <div style={styles.leftButtons}>
    <button
      onClick={() => setFilterOpen(!filterOpen)}
      style={{
        ...styles.advancedButton,
        color: filterOpen ? '#ffffff' : '#374151',
        backgroundColor: filterOpen ? '#374151' : '#ffffff',
      }}
    >
      <FunnelIcon style={styles.icon} />
      Advanced Filters
      {filterCount > 0 && <span style={styles.badge}>{filterCount}</span>}
    </button>

    <button
      onClick={() => setTargetModalOpen(true)}
      disabled={!business}
      style={{
        ...styles.exportButton,
        backgroundColor: business ? '#ffffff' : '#ffffff',
        opacity: business ? 1 : 0.6,
      }}
    >
      🎯 Manage Targets
    </button>
  </div>

  <div style={styles.rightButtons}>
    <button
  onClick={fetchData}
  style={{
    ...styles.fetchButton,
    opacity: loading ? 0.7 : 1,
    cursor: loading ? 'wait' : 'pointer'
  }}
  disabled={loading}
>
  {loading ? (
    <>
      <span className="spinner" style={{ width: '12px', height: '12px', border: '2px solid #fff', borderTop: '2px solid transparent', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.8s linear infinite' }} />
      <span style={{ marginLeft: '6px' }}>Loading...</span>
    </>
  ) : (
    <>
      <MagnifyingGlassIcon style={styles.icon} />
      Fetch
    </>
  )}
</button>


    <button
      onClick={exportMainDataToCSV}
      disabled={!rowData || rowData.length === 0}
      style={{
        ...styles.exportButton,
        opacity: !rowData || rowData.length === 0 ? 0.5 : 1,
      }}
    >
      <ArrowDownTrayIcon style={styles.icon} />
      Export CSV
    </button>

    <button
      onClick={() => exportToGoogleSheet(business, rowData)}
      disabled={!rowData || rowData.length === 0 || !business}
      style={{
        ...styles.exportButton,
        backgroundColor: '#ffffff',
        opacity: (!rowData || rowData.length === 0 || !business) ? 0.5 : 1,
      }}
    >
      📤 Export to Google Sheet
    </button>
  </div>
</div>
</div>
  );
};

// Styles unchanged
const baseSelectInput = {
  padding: '4px 8px',
  fontSize: '12.5px',
  borderRadius: '6px',
  backgroundColor: '#ffffff',
  border: '1px solid #cbd5e1',
  color: '#1e293b',
  height: '30px',
  boxShadow: '0 1px 1px rgba(0, 0, 0, 0.04)',
};

const styles = {
  container: {
    backgroundColor: '#ffffff',
    padding: '12px',
    borderRadius: '10px',
    marginBottom: '12px',
    border: '1px solid #e2e8f0',
    boxShadow: '0 1px 4px rgba(0, 0, 0, 0.05)',
  },
  selectInput: baseSelectInput,
  inputRow: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '10px',
    marginBottom: '10px',
  },
  buttonRow: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '160px',
    flex: 1,
  },
  label: {
    marginBottom: '4px',
    fontSize: '12px',
    color: '#475569',
    fontWeight: '600',
  },
  input: {
    padding: '4px 8px',
    fontSize: '12.5px',
    borderRadius: '6px',
    backgroundColor: '#ffffff',
    border: '1px solid #cbd5e1',
    color: '#1e293b',
    height: '21px',
  },
  monthSelector: {
    display: 'flex',
    gap: '4px',
  },
  monthInput: {
    ...baseSelectInput,
    flex: 1,
  },
  yearInput: {
    ...baseSelectInput,
    width: '70px',
  },
  weekSelector: {
    display: 'flex',
    gap: '4px',
  },
  weekInput: {
    ...baseSelectInput,
    flex: 1,
  },
  leftButtons: {
  display: 'flex',
  gap: '8px',
  flexWrap: 'wrap',
},

rightButtons: {
  display: 'flex',
  gap: '8px',
  flexWrap: 'wrap',
  marginLeft: 'auto', // ✅ Pushes this group to the right
},

buttonRow: {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: '12px',
},

  advancedButton: {
    padding: '4px 8px',
    backgroundColor: '#ffffff', 
    color: '#374151',
    fontSize: '12px',
    fontWeight: 500,
    borderRadius: '6px',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    border: '1px solid #d1d5db',
    cursor: 'pointer',
    height: '30px',
  },
  fetchButton: {
    padding: '4px 8px',
    backgroundColor: '#2563eb',
    color: '#ffffff',
    fontSize: '12px',
    fontWeight: 500,
    borderRadius: '6px',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    border: 'none',
    cursor: 'pointer',
    height: '30px',
    minWidth: '110px',
  },
  exportButton: {
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  padding: '6px 16px', // Reduced vertical padding
  fontSize: '13px', // Consistent with other elements
  fontWeight: '500',
  borderRadius: '6px',
  border: '1px solid #d1d5db',
  backgroundColor: '#ffffff',
  color: '#374151',
  cursor: 'pointer',
  transition: 'all 0.15s ease',
  height: '29px', // Match input height
  boxSizing: 'border-box',
},
  icon: {
    width: '12px',
    height: '12px',
  },
  badge: {
    backgroundColor: '#0ea5e9',
    color: '#fff',
    borderRadius: '9999px',
    padding: '1px 5px',
    fontSize: '10px',
    fontWeight: 'bold',
    marginLeft: '6px',
    lineHeight: 1,
  },
};

export default ReportControls;
