import React from 'react';

const ViewButtonRenderer = (props) => {
  const handleClick = () => {
    if (props.onClick) {
      // Pass the entire params object to maintain consistency with ag-grid cell click
      props.onClick({
        data: props.data,
        value: props.value,
        colDef: {
          field: props.colDef.field
        }
      });
    }
  };

  // If no value or not an object, just display the value
  if (!props.value) return <span>-</span>;
  if (typeof props.value !== 'object' && props.value !== 'View') return <span>{props.value}</span>;
  
  return (
    <button
      onClick={handleClick}
      style={{
        padding: '6px 16px',
        background: 'linear-gradient(90deg, rgb(171, 100, 247) 0%, rgb(107, 159, 248) 120%)',
        color: '#fff',
        border: 'none',
        borderRadius: '10px',
        cursor: 'pointer',
        fontWeight: '500',
        fontSize: '14px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        transition: 'all 0.2s ease-in-out',
        width: '100%',
        textAlign: 'center'
      }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.15)'}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)'}
    >
      View
    </button>
  );
};

export default ViewButtonRenderer;