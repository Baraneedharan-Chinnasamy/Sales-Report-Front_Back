import React, { useState, useMemo,useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import {ArrowDownTrayIcon,FunnelIcon,TrashIcon,} from '@heroicons/react/24/solid';
import useExportToSheet from './hooks/useExportToSheet';


const DetailsModal = ({
  showModal,
  closeModal,
  modalTitle,
  modalGridRef,
  modalRowData,
  modalColumnDefs,
  modalLoading,
  showModalExport,
  exportModalDataToCSV,
  onCellClicked,
  groupByField,
  handleGroupByChange,
  appliedFilters,
  setFilterOpen,
  business,
  fetchFullData,
  currentRowDate,
  sizeColumns = []
}) => {
  const [selectedGroupings, setSelectedGroupings] = useState(groupByField ? groupByField.split(',') : []);
  useEffect(() => {
  if (showModal) {
    setSelectedGroupings(groupByField ? groupByField.split(',') : []);
  }
}, [showModal, groupByField]);
  

 const { exportToGoogleSheet, loading, successMessage, error } = useExportToSheet();



  // Format Indian currency with ₹ symbol and comma separators
  const formatIndianCurrency = (value) => {
    if (value === null || value === undefined || isNaN(value)) return '—';
    
    // Convert to number if it's a string
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    
    // Format with Indian numbering system (lakh, crore)
    const formattedValue = numValue.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      style: 'decimal'
    });
    
    return `₹ ${formattedValue}`;
  };

  // Enhanced modal column definition with proper formatting
  const enhancedModalColumnDefs = useMemo(() => {
    if (!modalRowData || modalRowData.length === 0) return modalColumnDefs;

    const columns = modalColumnDefs.map((col) => {
      const key = col.field;
      const fieldLower = key?.toLowerCase?.() || '';
      const headerLower = col.headerName?.toLowerCase?.() || '';
      const enhancedCol = { ...col };

      // Growth percentage formatter
      if (key === "Sale_Growth_Percentage" || fieldLower.includes("growth") || headerLower.includes("growth")) {
        enhancedCol.cellRenderer = (params) => {
          const val = params.value;
          if (val === null || val === undefined || val === "N/A" || isNaN(val)) return '—';
          const value = parseFloat(val);
          const isPositive = value >= 0;
          const arrow = isPositive ? '▲' : '▼';
          const color = isPositive ? 'green' : 'red';
          return <span style={{ color, fontWeight: 'bold' }}>{arrow} {Math.abs(value).toFixed(2)}%</span>;
        };
      }

      // Deviation percentage formatter
      if (key === "%_Deviation" || fieldLower.includes("deviation") || headerLower.includes("deviation")) {
        enhancedCol.cellRenderer = (params) => {
          const val = params.value;
          if (val === null || val === undefined || val === "N/A" || isNaN(val)) return '—';
          const value = parseFloat(val);
          const isPositive = value >= 0;
          const arrow = isPositive ? '▲' : '▼';
          const color = isPositive ? 'green' : 'red';
          return <span style={{ color, fontWeight: 'bold' }}>{arrow} {Math.abs(value).toFixed(2)}%</span>;
        };
      }

      // Sell through rate formatter
      if (key === "Sell_Through_Rate" || fieldLower.includes("sell_through") || headerLower.includes("sell through")) {
        enhancedCol.cellRenderer = (params) => {
          const val = parseFloat(params.value);
          if (isNaN(val) || val === null || val === undefined) return '—';
          return <span style={{ fontWeight: 'bold', color: '#1e293b', textAlign: 'right', display: 'block' }}>{val.toFixed(2)}%</span>;
        };
        enhancedCol.cellStyle = { textAlign: 'right' };
      }

      // Conversion rate formatter
      if (key === 'Conversion_Rate' || fieldLower.includes('conversion') || headerLower.includes('conversion')) {
        enhancedCol.cellRenderer = (params) => {
          const val = parseFloat(params.value);
          if (isNaN(val)) return '—';
          let color = '#1e293b';
          if (val >= 25) color = 'green';
          else if (val >= 10) color = '#374151';
          else color = 'red';
          return <span style={{ fontWeight: 'bold', color, textAlign: 'right', display: 'block' }}>{val.toFixed(2)}%</span>;
        };
        enhancedCol.cellStyle = { textAlign: 'right' };
      }

      // Money value formatter - for Total Sale Value, Current Stock Value, etc.
      if (
        fieldLower.includes('sale value') || 
        fieldLower.includes('stock value') ||
        fieldLower.includes('price') ||
        fieldLower.includes('revenue') ||
        fieldLower.includes('amount') ||
        headerLower.includes('sale value') || 
        headerLower.includes('stock value') ||
        headerLower.includes('value') ||
        // Match specific column names from your image
        key === 'Total_Sale_Value' ||
        key === 'Current_Stock_Value'
      ) {
        enhancedCol.cellRenderer = (params) => {
          const val = params.value;
          if (val === null || val === undefined || isNaN(val)) return '—';
          return <span style={{ fontWeight: '500', color: '#0f172a', textAlign: 'right', display: 'block' }}>
            {formatIndianCurrency(val)}
          </span>;
        };
        enhancedCol.cellStyle = { textAlign: 'right' };
      }

      // General number formatter for quantities, stock, etc.
      if (
        (
          fieldLower.includes('stock') ||
          fieldLower.includes('quantity') ||
          fieldLower.includes('number') ||
          fieldLower.includes('viewed') ||
          fieldLower.includes('cart') ||
          fieldLower.includes('sold') ||
          headerLower.includes('stock') ||
          headerLower.includes('quantity') ||
          headerLower.includes('sold') ||
          // Match specific column names from your image
          key === 'Total_Current_Stock' ||
          key === 'Total_Quantity_Sold'
        ) &&
        typeof modalRowData?.[0]?.[key] === 'number'
      ) {
        enhancedCol.valueFormatter = (params) => {
          const val = parseInt(params.value);
          return isNaN(val) ? '—' : val.toLocaleString('en-IN');
        };
        enhancedCol.cellStyle = { textAlign: 'right', color: '#0f172a', fontWeight: 500 };
      }

      return enhancedCol;
    });

    // Enhanced Target column with combined data
    const hasTargetData = modalRowData[0]?.Target_Column && modalRowData[0]?.Target_Key && modalRowData[0]?.Target_Value !== undefined;

    if (hasTargetData) {
      const targetCol = {
        headerName: 'Target',
        field: 'Target',
        pinned: 'left',
        minWidth: 220,
        cellRenderer: (params) => {
          const row = params.data;
          const label = row?.Target_Column?.replace(/_/g, ' ') || '';
          const value = row?.Target_Key || '';
          const targetValue = formatIndianCurrency(row?.Target_Value);

          return (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'flex-start',
              height: '100%',
              padding: '6px 10px',
            }}>
              <div style={{ fontSize: '14px', color: '#475569' }}>
                <span style={{ fontWeight: 500 }}>{label}</span>{' '}
                <span style={{ fontWeight: 600, color: '#0f172a' }}>{value}</span>
              </div>
              <div style={{ fontSize: '13px', color: '#334155', marginTop: '4px', display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: '14px', marginRight: '4px' }}>🎯</span>
                <span style={{ fontWeight: 600 }}>Target:</span>&nbsp;
                <span style={{ fontWeight: 600, color: '#1e293b' }}>{targetValue}</span>
              </div>
            </div>
          );
        }
      };

      // Prepend to the start of the column list
      columns.unshift(targetCol);
    }

    return columns;
  }, [modalColumnDefs, modalRowData]);

  if (!showModal) return null;

  const groupingOptions = [
    { value: business === 'BEE7W5ND34XQZRM' ? 'Product_Type' : 'Category', label: business === 'BEE7W5ND34XQZRM' ? 'Product Type' : 'Category' },
    { value: 'Item_Type', label: 'Item Type' },
    { value: 'Item_Name', label: 'Item Name' },
    { value: 'Target_Column', label: 'Target Grouping' }
  ];

  const handleCheckboxChange = (field) => {
    setSelectedGroupings(prev =>
      prev.includes(field) ? prev.filter(f => f !== field) : [...prev, field]
    );
  };

  const handleApplyGrouping = () => {
    handleGroupByChange(selectedGroupings.join(','));
  };

  const handleClearGrouping = () => {
    setSelectedGroupings([]);
    handleGroupByChange('');
  };

  return (
    <div style={styles.modalOverlay}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <div style={styles.modalTitleSection}>
            <h3 style={styles.modalTitle}>{modalTitle}</h3>
            <div style={styles.modalDateInfo}>
              <span>
                {currentRowDate.startDate} {currentRowDate.startDate !== currentRowDate.endDate ? `to ${currentRowDate.endDate}` : ''}
              </span>
            </div>
          </div>
          <button onClick={closeModal} style={styles.closeButton}>×</button>
        </div>

        <div style={styles.modalControls}>
          <div style={styles.groupBySection}>
            <label style={styles.groupByLabel}>Group By:</label>
            <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
              {groupingOptions.map(option => (
  <label
    key={option.value}
    style={{
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '12.5px',
      fontWeight: 500,
      color: '#1e293b',
      padding: '6px 12px',
      backgroundColor: '#f8fafc',
      borderRadius: '6px',
      cursor: 'pointer',
      border: '1px solid transparent',
      transition: 'all 0.2s ease'
    }}
  >
    <input
      type="checkbox"
      checked={selectedGroupings.includes(option.value)}
      onChange={() => handleCheckboxChange(option.value)}
      style={{
        width: '12px',
        height: '12px',
        accentColor: '#2563eb',
        cursor: 'pointer'
      }}
    />
    {option.label}
  </label>
))}

              <div style={{ display: 'flex', gap: '10px', marginLeft: 'auto' }}>
                <button onClick={handleApplyGrouping} style={styles.exportButton}>
  <FunnelIcon style={{ width: 13, height: 13, marginRight: 4 }} />
  Apply Grouping
</button>

<button onClick={handleClearGrouping} style={styles.clearButton}>
  <TrashIcon style={{ width: 13, height: 13, marginRight: 4 }} />
  Clear All
</button>
              </div>
            </div>
          </div>

          <div style={styles.actionButtons}>
            {showModalExport && (
            <>
              <button onClick={exportModalDataToCSV} style={styles.exportButton}>
                <ArrowDownTrayIcon style={{ width: 13, height: 13, marginRight: 4 }} />
                Export CSV
              </button>
               <button
                onClick={() => exportToGoogleSheet(business, modalRowData)}
                disabled={!modalRowData || modalRowData.length === 0 || !business}
                style={{
                  ...styles.exportButton,
                  backgroundColor: '#22c55e',
                  opacity: (!modalRowData || modalRowData.length === 0 || !business) ? 0.5 : 1,
                }}
              >
                📤 Export to Google Sheet
              </button>

            </>
          )}
          </div>
        </div>

        {modalLoading ? (
          <div style={styles.loadingIndicator}>Loading details...</div>
        ) : (
          <div style={styles.gridContainer}>
            <div className="ag-theme-alpine" style={{ height: '500px', width: '100%' }}>
              <AgGridReact
                ref={modalGridRef}
                rowData={modalRowData}
                columnDefs={enhancedModalColumnDefs}
                rowHeight={40}
                rowStyle={{ boxShadow: 'inset 0 -1px 0 #e2e8f0' }}
                defaultColDef={{
                  flex: 1,
                  sortable: true,
                  filter: true,
                  resizable: true
                }}
                onCellClicked={(params) => {
                  if (sizeColumns.includes(params.colDef.field) && params.value) {
                    onCellClicked(params);
                  }
                }}
                onGridReady={(params) => {
                  params.api.sizeColumnsToFit();
                }}
                onFirstDataRendered={(params) => {
                  params.api.sizeColumnsToFit();
                }}
                pagination={true}
                paginationPageSize={15}
              />
            </div>
          </div>
        )}

        <div style={styles.modalFooter}>
          <button onClick={closeModal} style={styles.closeButtonFooter}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  modalContent: {
  backgroundColor: '#ffffff',
  borderRadius: '12px',
  width: '95%',
  maxWidth: '1400px',
  maxHeight: '90vh',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  boxShadow: '0 6px 30px rgba(0,0,0,0.15)',
}
,
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '16px 24px',
    borderBottom: '1px solid #e2e8f0',
    backgroundColor: '#f8fafc'
  },
  modalTitleSection: {
    display: 'flex',
    flexDirection: 'column'
  },
  modalTitle: {
  margin: 0,
  fontSize: '16px',
  fontWeight: '700',
  color: '#0f172a',
  letterSpacing: '-0.5px'
}
,
  modalDateInfo: {
  fontSize: '14px',
  color: '#64748b',
  fontWeight: '500',
  marginTop: '4px'
}
,
  closeButton: {
    background: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#64748b',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    transition: 'background-color 0.2s'
  },
  
  groupBySection: {
  display: 'flex',
  flexDirection: 'column',
  backgroundColor: '#f8fafc',
  border: '1px solid transparent',
  borderRadius: '12px',
  padding: '6px 10px',
  marginBottom: '4px'
}

,
  groupByLabel: {
  fontSize: '12px',
  fontWeight: '600',
  color: '#475569',
  letterSpacing: '0.4px',
  textTransform: 'uppercase',
  marginBottom: '6px'
}
,
  modalControls: {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '0px 24px',
  backgroundColor: '#f8fafc',
  borderBottom: '1px solid #e2e8f0',
  flexWrap: 'wrap',
  gap: '10px'
},
actionButtons: {
  display: 'flex',
  gap: '10px',
  alignItems: 'center',
  flexWrap: 'wrap'
},
checkboxContainer: {
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  flexWrap: 'wrap',
  marginTop: '8px'
},
checkboxLabel: {
  padding: '5px 10px',
  fontSize: '13px',
  gap: '4px',
  borderRadius: '6px'
}
,
  exportButton: {
    padding: '4px 10px',
    backgroundColor: '#2563eb',
    color: '#ffffff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '12px',
    cursor: 'pointer',
    fontWeight: '500',
    transition: 'background-color 0.2s'
  },
  clearButton: {
    padding: '6px 12px',
    backgroundColor: '#94a3b8',
    color: '#ffffff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '12px',
    cursor: 'pointer',
    fontWeight: '500',
    transition: 'background-color 0.2s'
  },
  loadingIndicator: {
    padding: '40px',
    textAlign: 'center',
    color: '#64748b',
    fontSize: '16px'
  },
  gridContainer: {
  flex: 1,
  overflow: 'hidden',
  padding: '0 24px 0 24px',
  display: 'flex',
  flexDirection: 'column',
  minHeight: 0 // 🔥 ensures it doesn't overflow parent flex
}
,
 modalFooter: {
  display: 'flex',
  justifyContent: 'flex-end',
  padding: '12px 24px',
  backgroundColor: '#f8fafc',
  borderTop: '1px solid #e2e8f0',
  flexShrink: 0
},
closeButtonFooter: {
  padding: '6px 12px',
  backgroundColor: '#ef4444',
  color: '#ffffff',
  border: 'none',
  borderRadius: '6px',
  fontSize: '12px',
  cursor: 'pointer',
  fontWeight: '500'
}

};

export default DetailsModal;